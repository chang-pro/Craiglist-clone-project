// src/components/ui/header/select-language-button.tsx
"use client";

export default function SelectLanguageButton() {
  return (
    <button className="border rounded px-2 py-1">
      English
    </button>
  );
}